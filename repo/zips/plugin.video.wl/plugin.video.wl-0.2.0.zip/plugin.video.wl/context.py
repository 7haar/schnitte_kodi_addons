import xbmc
import xbmcgui

if __name__ == '__main__':
    xbmc.executebuiltin(f'RunPlugin(plugin://plugin.video.wl/?action=add)')