 # Resolve and start playback via xbmcplugin
    xbmcplugin.setResolvedUrl(HANDLE, succeeded=True, listitem=listitem, url=url)

    # Now wait for player to start. Use xbmc.Player instance to control seek.
    player = xbmc.Player()
    start = time.time()
    timeout = 15.0
    while time.time() - start < timeout:
        if player.isPlaying():
            break
        time.sleep(0.2)

    # load resume store and apply resume if present
    store = load_store()
    resume = store.get(key)
    if resume:
        pos = int(resume.get('position', 0))
        # seek after playback actually started: try seekTime, else fraction
        try:
            # seekTime(seconds) exists in newer Kodi versions
            player.seekTime(pos)
        except Exception:
            try:
                dur = resume.get('duration') or item.get('duration') or 0
                if dur:
                    fraction = pos / float(max(1, dur))
                    player.seek(fraction)
            except Exception:
                pass

    # start monitor thread to persist resume points
    monitor = ResumeMonitor(player, key, item.get('duration') or resume.get('duration') if resume else item.get('duration'), store)
    monitor.start()

    # Option A: block until playback stops (service-style)
    while player.isPlaying():
        # allow graceful abort via xbmc.Monitor if needed
        time.sleep(1)

    # playback ended — stop monitor
    monitor.stop()
    monitor.join()--