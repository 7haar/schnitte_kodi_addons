import xbmc
import xbmcgui
import json

class PlaylistMonitor(xbmc.Player):
    def __init__(self, result):
        self.result = result
        xbmc.Player.__init__(self)
        xbmcgui.Dialog().notification(f"player start", f"start", xbmcgui.NOTIFICATION_INFO, 2000)
    
    def onAVStarted(self):
        current_file = self.getPlayingFile()
        
        for idx, ep in enumerate(self.result):
            if ep['file'] == current_file:
                remaining = len(self.result) - (idx + 1)
                
                xbmcgui.Dialog().notification(
                    'Playlist Monitor',
                    f'Erkannt: {ep.get("title", "Unbekannt")} | Füge {remaining} weitere Episodes hinzu',
                    xbmcgui.NOTIFICATION_INFO,
                    3000  # 3 Sekunden
                )
                
                self._fill_playlist_from(idx + 1)
                break
    
    def _fill_playlist_from(self, start_index):
        import json
        added = 0
        for ep in self.result[start_index:]:
            xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0",
                "method": "Playlist.Add",
                "params": {
                    "playlistid": 1,
                    "item": {"episodeid": ep["episodeid"]}
                },
                "id": 1
            }))
            added += 1
        
        xbmcgui.Dialog().notification(
            'Playlist Monitor',
            f'{added} Episoden zur Playlist hinzugefügt ✓',
            xbmcgui.NOTIFICATION_INFO,
            3000
        )